ECHO est� ativado.
