// Banco de dados completo e detalhado dos jogos para renderização dinâmica nos Modais
const gamesData = {
    "cyber-horizon": {
        title: "Cyber Horizon",
        synopsis: "Mergulhe em uma megalópole futurista controlada por mega-corporações imperdoáveis. Customizados com melhorias cibernéticas avançadas, lute por sobrevivência e controle o fluxo de informações da rede global neste RPG de mundo aberto massivo.",
        creators: "Vortex Alpha Team",
        year: "2025",
        img: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=500&q=80"
    },
    "shadow-pulse": {
        title: "Shadow Pulse",
        synopsis: "O ápice do combate tático furtivo em arenas de ritmo acelerado 5v5. Utilize a escuridão e manipule frequências sônicas para surpreender seus inimigos antes que eles detectem seus movimentos.",
        creators: "Vortex Crimson Team",
        year: "2024",
        img: "https://images.unsplash.com/photo-1553481187-be93c21490a9?auto=format&fit=crop&w=500&q=80"
    },
    "neon-race": {
        title: "Neon Race 2088",
        synopsis: "Corridas extremas de anti-gravidade através de pistas flutuantes banhadas em neon. Sintetize energia e acelere além da barreira do som impulsionado por uma trilha Synthwave interativa.",
        creators: "Vortex Speed division",
        year: "2025",
        img: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=500&q=80"
    },
    "pixel-overlord": {
        title: "Pixel Overlord",
        synopsis: "Comande hordas de monstros e proteja sua masmorra de heróis gananciosos neste charmoso e estratégico simulador em pixel art retrô com alta profundidade tática.",
        creators: "Vortex Retro Lab",
        year: "2023",
        img: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&w=500&q=80"
    },
    "vortex-arena": {
        title: "Vortex Arena",
        synopsis: "O MOBA definitivo projetado para competições profissionais de eSports. Escolha entre heróis lendários com habilidades combinatórias espetaculares em batalhas de rotas dinâmicas.",
        creators: "Vortex Global Competitive",
        year: "2026",
        img: "https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&w=500&q=80"
    },
    "chrono-trigger": {
        title: "Chrono Trigger X",
        synopsis: "Uma homenagem cinematográfica aos maiores épicos de viagem no tempo. Altere o passado para reescrever o destino de civilizações em um RPG focado em escolhas morais.",
        creators: "Vortex Eastern Studios",
        year: "2024",
        img: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=500&q=80"
    },
    "apex-hunter": {
        title: "Apex Hunter",
        synopsis: "A caçada mais realista do mercado de games. Gerencie fatores biológicos vitais, estude rastros complexos e domine biomas selvagens perigosos jogando sozinho ou em cooperativo.",
        creators: "Vortex Wildlands Dept.",
        year: "2024",
        img: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=500&q=80"
    },
    "mecha-assault": {
        title: "Mecha Assault",
        synopsis: "Entre no cockpit de robôs mecânicos colossais totalmente customizáveis. Participe de guerras destrutivas urbanas com física realista de colisão e armamento bélico pesado.",
        creators: "Vortex Steel Core",
        year: "2025",
        img: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=500&q=80"
    },
    "mythic-legends": {
        title: "Mythic Legends",
        synopsis: "Colecione divindades mitológicas e construa o baralho definitivo. Use feitiços antigos e cartas de poder dinâmicas em confrontos mentais um contra um ranqueados.",
        creators: "Vortex Card Labs",
        year: "2025",
        img: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80"
    },
    "cosmic-voyager": {
        title: "Cosmic Voyager",
        synopsis: "Exploração espacial definitiva em escala galáctica procedural. Pilote naves personalizadas, faça comércio interestelar legítimo ou ataque piratas em combates espaciais intensos.",
        creators: "Vortex Horizon Line",
        year: "2025",
        img: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=500&q=80"
    },
    "speed-velocity": {
        title: "Speed Velocity",
        synopsis: "Sinta cada curva e o desgaste dos pneus neste simulador de automobilismo ultra-realista. Desenvolvido com feedback de pilotos profissionais e telemetria de ponta.",
        creators: "Vortex Racing Division",
        year: "2026",
        img: "https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&w=500&q=80"
    },
    "dead-zone": {
        title: "Dead Zone",
        synopsis: "Um apocalipse severo onde cada recurso conta. Construa fortificações impenetráveis, faça alianças instáveis e defenda seu território de hordas mutantes infectadas.",
        creators: "Vortex Outbreak Studio",
        year: "2024",
        img: "https://images.unsplash.com/photo-1511882150382-421056c89033?auto=format&fit=crop&w=500&q=80"
    }
};

// Estado global do aplicativo
let cart = [];

// Elementos DOM
const gameDetailModal = document.getElementById('gameDetailModal');
const checkoutForm = document.getElementById('checkoutForm');
const modalGameTitle = document.getElementById('modalGameTitle') || null;
const modalGameSynopsis = document.getElementById('modalGameSynopsis');
const modalGameImg = document.getElementById('modalGameImg');
const closeDetailBtn = document.getElementById('closeDetailBtn');

const cartModal = document.getElementById('cartModal');
const openCartBtn = document.getElementById('openCartBtn');
const closeCartModalBtn = document.getElementById('closeCartModalBtn');
const cartItemsList = document.getElementById('cartItemsList');
const cartCount = document.getElementById('cartCount');
const cartTotalItems = document.getElementById('cartTotalItems');
const btnCheckoutCart = document.getElementById('btnCheckoutCart');
const paymentOptions = document.querySelectorAll('.payment-option');
const paymentDescription = document.getElementById('paymentDescription');
const cardFields = document.getElementById('cardFields');
const pixCode = document.getElementById('pixCode');
const copyPixBtn = document.getElementById('copyPixBtn');
let currentPaymentMethod = 'card';
let currentGameId = null;

// Novos modais de pagamento
const pixPaymentModal = document.getElementById('pixPaymentModal');
const cardPaymentModal = document.getElementById('cardPaymentModal');
const closePixModalBtn = document.getElementById('closePixModalBtn');
const closeCardModalBtn = document.getElementById('closeCardModalBtn');
const pixPaymentBtn = document.getElementById('pixPaymentBtn');
const cardPaymentBtn = document.getElementById('cardPaymentBtn');
const copyPixBtnModal = document.getElementById('copyPixBtnModal');

const loginModal = document.getElementById('loginModal');
const openLoginBtn = document.getElementById('openLoginBtn');
const closeLoginBtn = document.getElementById('closeLoginBtn');
const mobileMenu = document.getElementById('mobileMenu');
const menuNav = document.querySelector('.menu');

// Sistema de autenticação
let isUserAuthenticated = localStorage.getItem('userAuthenticated') === 'true';
let currentUserEmail = localStorage.getItem('userEmail') || null;

// Sistema de jogos comprados
let purchasedGames = JSON.parse(localStorage.getItem('purchasedGames')) || [];

// Função para verificar autenticação
function checkAuthentication() {
    return isUserAuthenticated;
}

// Função para atualizar UI de autenticação
function updateAuthenticationUI() {
    const openLoginBtn = document.getElementById('openLoginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const userEmailDisplay = document.getElementById('userEmailDisplay');
    
    if (isUserAuthenticated && currentUserEmail) {
        if (openLoginBtn) openLoginBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'block';
        if (userEmailDisplay) {
            userEmailDisplay.style.display = 'inline-block';
            userEmailDisplay.innerText = `👤 ${currentUserEmail}`;
        }
    } else {
        if (openLoginBtn) openLoginBtn.style.display = 'block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (userEmailDisplay) userEmailDisplay.style.display = 'none';
    }
}

// Inicializar UI na página
updateAuthenticationUI();

// Função para preencher e construir a estrutura do modal
function populateGameModal(gameInfo, isCartCheckout = false) {
    if (modalGameTitle) {
        modalGameTitle.innerText = gameInfo.title;
    }
    modalGameSynopsis.innerText = gameInfo.synopsis;
    modalGameImg.style.backgroundImage = `url('${gameInfo.img}')`;

    const creatorsSpan = document.getElementById('modalGameCreators');
    const yearSpan = document.getElementById('modalGameYear');

    if (creatorsSpan) {
        creatorsSpan.innerText = isCartCheckout ? 'Vários' : (gameInfo.creators || 'Vortex Team');
    }
    if (yearSpan) {
        yearSpan.innerText = isCartCheckout ? 'Atual' : (gameInfo.year || '2026');
    }
}

// --- LÓGICA DE CLIQUE NOS CARDS DE JOGO ---
document.querySelectorAll('.game-card').forEach(card => {
    card.addEventListener('click', function(e) {
        const gameId = this.getAttribute('data-id');
        const gameInfo = gamesData[gameId];
        
        if (!gameInfo) return;

        // Caso 1: Clicou no botão "Comprar Agora"
        if (e.target.closest('.btn-buy')) {
            e.stopPropagation(); // Evita ativar o clique do card pai
            
            // Verificar se o usuário está autenticado
            if (!checkAuthentication()) {
                alert('Para comprar, você precisa estar conectado ou se cadastrar.');
                loginModal.classList.add('active');
                return;
            }
            
            populateGameModal(gameInfo);
            
            // Exibe os campos de pagamento
            checkoutForm.style.display = 'block';
            gameDetailModal.classList.add('active', 'checkout-mode');
        } 
        // Caso 2: Clicou no ícone do carrinho dentro do card
        else if (e.target.closest('.btn-cart-icon')) {
            e.stopPropagation();
            addToCart(gameId);
        } 
        // Caso 3: Clicou em qualquer outro lugar do card (Apenas descrição)
        else {
            populateGameModal(gameInfo);
            
            // Oculta o formulário de pagamento para exibir apenas detalhes
            checkoutForm.style.display = 'none';
            gameDetailModal.classList.remove('checkout-mode');
            gameDetailModal.classList.add('active');
        }
    });
});

// Fechar Modal de detalhes
closeDetailBtn.addEventListener('click', () => {
    gameDetailModal.classList.remove('active', 'checkout-mode');
});

// --- SISTEMA DO CARRINHO ---

function addToCart(gameId) {
    const game = gamesData[gameId];
    if (!game) return;

    // Impede duplicados no carrinho
    if (cart.some(item => item.id === gameId)) {
        alert(`${game.title} já está no seu carrinho!`);
        return;
    }

    cart.push({ id: gameId, title: game.title, img: game.img });
    updateCartUI();
    alert(`${game.title} foi adicionado ao carrinho.`);
}

function removeFromCart(gameId) {
    cart = cart.filter(item => item.id !== gameId);
    updateCartUI();
    renderCartItems();
}

// Tratamento preventivo caso os elementos do contador de carrinho não existam em todas as páginas
function updateCartUI() {
    if (cartCount) cartCount.innerText = cart.length;
    if (cartTotalItems) cartTotalItems.innerText = cart.length;
}

function renderCartItems() {
    if (!cartItemsList) return;
    cartItemsList.innerHTML = '';
    
    if (cart.length === 0) {
        cartItemsList.innerHTML = '<p class="empty-cart-text">Seu carrinho está vazio.</p>';
        return;
    }

    cart.forEach(item => {
        const itemRow = document.createElement('div');
        itemRow.className = 'cart-item-row';
        itemRow.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-thumb" style="background-image: url('${item.img}')"></div>
                <span>${item.title}</span>
            </div>
            <button class="btn-remove-item" onclick="removeFromCart('${item.id}')" title="Remover">
                <i class="fa-solid fa-trash"></i>
            </button>
        `;
        cartItemsList.appendChild(itemRow);
    });
}

function renderPurchasedGames() {
    const purchasedGamesSection = document.getElementById('purchasedGamesSection');
    const purchasedGamesList = document.getElementById('purchasedGamesList');
    
    if (!purchasedGamesList) return;
    
    if (purchasedGames.length === 0) {
        purchasedGamesSection.style.display = 'none';
        return;
    }
    
    purchasedGamesSection.style.display = 'block';
    purchasedGamesList.innerHTML = '';
    
    purchasedGames.forEach(item => {
        const itemRow = document.createElement('div');
        itemRow.className = 'cart-item-row';
        itemRow.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-thumb" style="background-image: url('${item.img}')"></div>
                <div style="flex: 1;">
                    <span style="font-weight: 700;">${item.title}</span>
                    <p style="font-size: 0.8rem; color: var(--text-gray); margin-top: 4px;">Comprado em: ${item.purchaseDate}</p>
                </div>
            </div>
            <div style="color: var(--green-neon); font-weight: 800;">✓</div>
        `;
        purchasedGamesList.appendChild(itemRow);
    });
}

// Abrir e Fechar Modal do Carrinho Superior
if (openCartBtn) {
    openCartBtn.addEventListener('click', () => {
        renderCartItems();
        renderPurchasedGames();
        if (cartModal) cartModal.classList.add('active');
    });
}

if (closeCartModalBtn) {
    closeCartModalBtn.addEventListener('click', () => {
        if (cartModal) cartModal.classList.remove('active');
    });
}

// Ação de Checkout do Carrinho Completo
if (btnCheckoutCart) {
    btnCheckoutCart.addEventListener('click', () => {
        if (cart.length === 0) {
            alert("Adicione pelo menos um jogo para prosseguir!");
            return;
        }
        
        // Verificar se o usuário está autenticado
        if (!checkAuthentication()) {
            alert('Para comprar, você precisa estar conectado ou se cadastrar.');
            if (cartModal) cartModal.classList.remove('active');
            loginModal.classList.add('active');
            return;
        }
        
        if (cartModal) cartModal.classList.remove('active');
        
        // Passa um objeto genérico baseado no primeiro item do carrinho
        const checkoutInfo = {
            title: "Finalizar Pedido do Carrinho",
            synopsis: `Você está adquirindo ${cart.length} jogo(s) selecionado(s).`,
            img: cart[0].img
        };
        
        populateGameModal(checkoutInfo, true);
        
        checkoutForm.style.display = 'block';
        gameDetailModal.classList.add('active', 'checkout-mode');
    });
}

// --- MODAL DO DETALHE DO JOGO (SELEÇÃO DE MÉTODO DE PAGAMENTO) ---

// Função para gerar QR code
function generateQRCode(pixCode) {
    const qrcodeContainer = document.getElementById('qrcodeModal');
    // Limpar QR code anterior
    qrcodeContainer.innerHTML = '';
    // Gerar novo QR code
    new QRCode(qrcodeContainer, {
        text: pixCode,
        width: 150,
        height: 150,
        colorDark: '#32d912',
        colorLight: '#000000'
    });
}

paymentOptions.forEach(button => {
    button.addEventListener('click', () => {
        paymentOptions.forEach(opt => opt.classList.remove('active'));
        button.classList.add('active');
        const method = button.dataset.method;
        currentPaymentMethod = method;
        
        // Obter informações do jogo atual
        const gameTitle = document.getElementById('modalGameTitle')?.innerText || 'Seu Jogo';
        
        if (method === 'pix') {
            // Atualizar título do jogo no modal de PIX
            document.getElementById('pixGameTitle').innerText = gameTitle;
            // Fechar modal anterior e abrir modal de PIX
            gameDetailModal.classList.remove('active');
            pixPaymentModal.classList.add('active');
            // Gerar QR code
            const pixCode = document.getElementById('pixValueModal').innerText;
            generateQRCode(pixCode);
        } else {
            // Atualizar título do jogo no modal de Cartão
            document.getElementById('cardGameTitle').innerText = gameTitle;
            // Fechar modal anterior e abrir modal de Cartão
            gameDetailModal.classList.remove('active');
            cardPaymentModal.classList.add('active');
        }
    });
});

if (copyPixBtnModal) {
    copyPixBtnModal.addEventListener('click', () => {
        const pixText = document.getElementById('pixValueModal').innerText;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(pixText).then(() => {
                alert('Código PIX copiado para a área de transferência.');
            }).catch(() => {
                alert('Não foi possível copiar. Selecione e copie manualmente.');
            });
        } else {
            alert('Navegador não suporta cópia automática. Selecione e copie manualmente.');
        }
    });
}

// Event listeners para fechar os modais de pagamento
if (closePixModalBtn) {
    closePixModalBtn.addEventListener('click', () => {
        pixPaymentModal.classList.remove('active');
        gameDetailModal.classList.add('active');
        // Resetar payment options
        paymentOptions.forEach(opt => opt.classList.remove('active'));
        document.querySelector('[data-method="card"]').classList.add('active');
    });
}

if (closeCardModalBtn) {
    closeCardModalBtn.addEventListener('click', () => {
        cardPaymentModal.classList.remove('active');
        gameDetailModal.classList.add('active');
        // Resetar payment options
        paymentOptions.forEach(opt => opt.classList.remove('active'));
        document.querySelector('[data-method="card"]').classList.add('active');
    });
}

// Event listeners para os formulários de pagamento dos novos modais
const pixPaymentForm = document.getElementById('pixPaymentForm');
const cardPaymentForm = document.getElementById('cardPaymentForm');

if (pixPaymentForm) {
    pixPaymentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const pixText = document.getElementById('pixValueModal').innerText;
        alert('Use o código PIX exibido para realizar o pagamento:\n' + pixText);
        // Fechar modal e limpar carrinho
        pixPaymentModal.classList.remove('active');
        cart = [];
        updateCartUI();
    });
}

if (cardPaymentForm) {
    cardPaymentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('checkoutName').value.trim();
        const email = document.getElementById('checkoutEmail').value.trim();
        const cardNum = document.getElementById('checkoutCard').value.trim();
        const expiry = document.getElementById('checkoutExpiry').value.trim();
        const cvv = document.getElementById('checkoutCvv').value.trim();

        if (!name || !email || !cardNum || !expiry || !cvv) {
            alert('Preencha todos os dados do cartão para concluir a compra.');
            return;
        }

        // Adicionar os jogos do carrinho aos jogos comprados
        const currentDate = new Date().toLocaleDateString('pt-BR');
        cart.forEach(item => {
            purchasedGames.push({
                id: item.id,
                title: item.title,
                img: item.img,
                purchaseDate: currentDate
            });
        });
        
        // Salvar jogos comprados no localStorage
        localStorage.setItem('purchasedGames', JSON.stringify(purchasedGames));

        alert("Compra realizada com sucesso! Seus jogos digitais foram enviados para " + email);
        cardPaymentModal.classList.remove('active');
        cart = [];
        updateCartUI();
        this.reset();
    });
}

// --- MODAL DE LOGIN GENÉRICO E MENU MOBILE ---
if (openLoginBtn) openLoginBtn.addEventListener('click', () => loginModal && loginModal.classList.add('active'));
if (closeLoginBtn) closeLoginBtn.addEventListener('click', () => loginModal && loginModal.classList.remove('active'));

// Toggle entre Login e Registro
const toggleRegister = document.getElementById('toggleRegister');
const toggleLogin = document.getElementById('toggleLogin');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const formFooter = document.querySelector('.form-footer');
const registerFooter = document.getElementById('registerFooter');

if (toggleRegister) {
    toggleRegister.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        formFooter.style.display = 'none';
        registerFooter.style.display = 'block';
    });
}

if (toggleLogin) {
    toggleLogin.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        formFooter.style.display = 'block';
        registerFooter.style.display = 'none';
    });
}

// Formulário de Login
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        
        // Validação básica
        if (!email || !password) {
            alert('Por favor, preencha e-mail e senha.');
            return;
        }
        
        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Por favor, insira um e-mail válido.');
            return;
        }
        
        // Validar senha (mínimo 6 caracteres)
        if (password.length < 6) {
            alert('A senha deve ter pelo menos 6 caracteres.');
            return;
        }
        
        // Autenticar usuário (simples - salva em localStorage)
        isUserAuthenticated = true;
        currentUserEmail = email;
        localStorage.setItem('userAuthenticated', 'true');
        localStorage.setItem('userEmail', email);
        
        alert(`Bem-vindo, ${email}!`);
        if (loginModal) loginModal.classList.remove('active');
        updateAuthenticationUI();
        this.reset();
    });
}

// Formulário de Registro
if (registerForm) {
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('registerName').value.trim();
        const email = document.getElementById('registerEmail').value.trim();
        const password = document.getElementById('registerPassword').value.trim();
        const confirmPassword = document.getElementById('registerConfirmPassword').value.trim();
        
        // Validação básica
        if (!name || !email || !password || !confirmPassword) {
            alert('Por favor, preencha todos os campos.');
            return;
        }
        
        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Por favor, insira um e-mail válido.');
            return;
        }
        
        // Validar senha (mínimo 6 caracteres)
        if (password.length < 6) {
            alert('A senha deve ter pelo menos 6 caracteres.');
            return;
        }
        
        // Validar confirmação de senha
        if (password !== confirmPassword) {
            alert('As senhas não coincidem.');
            return;
        }
        
        // Registrar usuário
        isUserAuthenticated = true;
        currentUserEmail = email;
        localStorage.setItem('userAuthenticated', 'true');
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userName', name);
        
        alert(`Conta criada com sucesso! Bem-vindo, ${name}!`);
        if (loginModal) loginModal.classList.remove('active');
        updateAuthenticationUI();
        
        // Voltar para formulário de login
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        formFooter.style.display = 'block';
        registerFooter.style.display = 'none';
        this.reset();
        loginForm.reset();
    });
}

// Botão de Logout
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        isUserAuthenticated = false;
        currentUserEmail = null;
        localStorage.removeItem('userAuthenticated');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userName');
        
        alert('Você foi desconectado!');
        updateAuthenticationUI();
        
        // Limpar carrinho se estava checando
        if (gameDetailModal && gameDetailModal.classList.contains('active')) {
            gameDetailModal.classList.remove('active', 'checkout-mode');
        }
    });
}

if (mobileMenu) {
    mobileMenu.addEventListener('click', () => {
        if (menuNav) menuNav.classList.toggle('active');
    });
}

// Fechar modais ao clicar na área escura (overlay)
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active', 'checkout-mode');
    }
});
