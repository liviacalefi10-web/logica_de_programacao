// Banco de dados completo e detalhado dos jogos para renderização dinâmica nos Modais
const gamesData = {
    "cyber-horizon": {
        title: "Cyber Horizon",
        synopsis: "Mergulhe em uma megalópole futurista controlada por mega-corporações imperdoáveis. Customizados com melhorias cibernéticas avançadas, lute por sobrevivência e controle o fluxo de informações da rede global neste RPG de mundo aberto massivo.",
        creators: "Vortex Alpha Team",
        year: "2025",
        img: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=500&q=80"
    },
    "shadow-pulse": {
        title: "Shadow Pulse",
        synopsis: "O ápice do combate tático furtivo em arenas de ritmo acelerado 5v5. Utilize a escuridão e manipule frequências sônicas para surpreender seus inimigos antes que eles detectem seus movimentos.",
        creators: "Vortex Crimson Team",
        year: "2024",
        img: "https://images.unsplash.com/photo-1553481187-be93c21490a9?auto=format&fit=crop&w=500&q=80"
    },
    "neon-race": {
        title: "Neon Race 2088",
        synopsis: "Corridas extremas de anti-gravidade através de pistas flutuantes banhadas em neon. Sintetize energia e acelere além da barreira do som impulsionado por uma trilha Synthwave interativa.",
        creators: "Vortex Speed division",
        year: "2025",
        img: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=500&q=80"
    },
    "pixel-overlord": {
        title: "Pixel Overlord",
        synopsis: "Comande hordas de monstros e proteja sua masmorra de heróis gananciosos neste charmoso e estratégico simulador em pixel art retrô com alta profundidade tática.",
        creators: "Vortex Retro Lab",
        year: "2023",
        img: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&w=500&q=80"
    },
    "vortex-arena": {
        title: "Vortex Arena",
        synopsis: "O MOBA definitivo projetado para competições profissionais de eSports. Escolha entre heróis lendários com habilidades combinatórias espetaculares em batalhas de rotas dinâmicas.",
        creators: "Vortex Global Competitive",
        year: "2026",
        img: "https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&w=500&q=80"
    },
    "chrono-trigger": {
        title: "Chrono Trigger X",
        synopsis: "Uma homenagem cinematográfica aos maiores épicos de viagem no tempo. Altere o passado para reescrever o destino de civilizações em um RPG focado em escolhas morais.",
        creators: "Vortex Eastern Studios",
        year: "2024",
        img: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=500&q=80"
    },
    "apex-hunter": {
        title: "Apex Hunter",
        synopsis: "A caçada mais realista do mercado de games. Gerencie fatores biológicos vitais, estude rastros complexos e domine biomas selvagens perigosos jogando sozinho ou em cooperativo.",
        creators: "Vortex Wildlands Dept.",
        year: "2024",
        img: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=500&q=80"
    },
    "mecha-assault": {
        title: "Mecha Assault",
        synopsis: "Entre no cockpit de robôs mecânicos colossais totalmente customizáveis. Participe de guerras destrutivas urbanas com física realista de colisão e armamento bélico pesado.",
        creators: "Vortex Steel Core",
        year: "2025",
        img: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=500&q=80"
    },
    "mythic-legends": {
        title: "Mythic Legends",
        synopsis: "Colecione divindades mitológicas e construa o baralho definitivo. Use feitiços antigos e cartas de poder dinâmicas em confrontos mentais um contra um ranqueados.",
        creators: "Vortex Card Labs",
        year: "2025",
        img: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80"
    },
    "cosmic-voyager": {
        title: "Cosmic Voyager",
        synopsis: "Exploração espacial definitiva em escala galáctica procedural. Pilote naves personalizadas, faça comércio interestelar legítimo ou ataque piratas em combates espaciais intensos.",
        creators: "Vortex Horizon Line",
        year: "2025",
        img: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=500&q=80"
    },
    "speed-velocity": {
        title: "Speed Velocity",
        synopsis: "Sinta cada curva e o desgaste dos pneus neste simulador de automobilismo ultra-realista. Desenvolvido com feedback de pilotos profissionais e telemetria de ponta.",
        creators: "Vortex Racing Division",
        year: "2026",
        img: "https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&w=500&q=80"
    },
    "dead-zone": {
        title: "Dead Zone",
        synopsis: "Um apocalipse severo onde cada recurso conta. Construa fortificações impenetráveis, faça alianças instáveis e defenda seu território de hordas mutantes infectadas.",
        creators: "Vortex Outbreak Studio",
        year: "2024",
        img: "https://images.unsplash.com/photo-1511882150382-421056c89033?auto=format&fit=crop&w=500&q=80"
    }
};

// Estado global do aplicativo
let cart = [];

// Elementos DOM
const gameDetailModal = document.getElementById('gameDetailModal');
const checkoutForm = document.getElementById('checkoutForm');
const modalGameTitle = document.getElementById('modalGameTitle') || null;
const modalGameSynopsis = document.getElementById('modalGameSynopsis');
const modalGameImg = document.getElementById('modalGameImg');
const closeDetailBtn = document.getElementById('closeDetailBtn');

const cartModal = document.getElementById('cartModal');
const openCartBtn = document.getElementById('openCartBtn');
const closeCartModalBtn = document.getElementById('closeCartModalBtn');
const cartItemsList = document.getElementById('cartItemsList');
const cartCount = document.getElementById('cartCount');
const cartTotalItems = document.getElementById('cartTotalItems');
const btnCheckoutCart = document.getElementById('btnCheckoutCart');
const paymentOptions = document.querySelectorAll('.payment-option');
const paymentDescription = document.getElementById('paymentDescription');
const cardFields = document.getElementById('cardFields');
const pixCode = document.getElementById('pixCode');
const copyPixBtn = document.getElementById('copyPixBtn');
let currentPaymentMethod = 'card';

const loginModal = document.getElementById('loginModal');
const openLoginBtn = document.getElementById('openLoginBtn');
const closeLoginBtn = document.getElementById('closeLoginBtn');
const mobileMenu = document.getElementById('mobileMenu');
const menuNav = document.querySelector('.menu');

// Função para preencher e construir a estrutura do modal
function populateGameModal(gameInfo, isCartCheckout = false) {
    if (modalGameTitle) {
        modalGameTitle.innerText = gameInfo.title;
    }
    modalGameSynopsis.innerText = gameInfo.synopsis;
    modalGameImg.style.backgroundImage = `url('${gameInfo.img}')`;

    const creatorsSpan = document.getElementById('modalGameCreators');
    const yearSpan = document.getElementById('modalGameYear');

    if (creatorsSpan) {
        creatorsSpan.innerText = isCartCheckout ? 'Vários' : (gameInfo.creators || 'Vortex Team');
    }
    if (yearSpan) {
        yearSpan.innerText = isCartCheckout ? 'Atual' : (gameInfo.year || '2026');
    }
}

// --- LÓGICA DE CLIQUE NOS CARDS DE JOGO ---
document.querySelectorAll('.game-card').forEach(card => {
    card.addEventListener('click', function(e) {
        const gameId = this.getAttribute('data-id');
        const gameInfo = gamesData[gameId];
        
        if (!gameInfo) return;

        // Caso 1: Clicou no botão "Comprar Agora"
        if (e.target.closest('.btn-buy')) {
            e.stopPropagation(); // Evita ativar o clique do card pai
            
            populateGameModal(gameInfo);
            
            // Exibe os campos de pagamento
            checkoutForm.style.display = 'block';
            gameDetailModal.classList.add('active', 'checkout-mode');
        } 
        // Caso 2: Clicou no ícone do carrinho dentro do card
        else if (e.target.closest('.btn-cart-icon')) {
            e.stopPropagation();
            addToCart(gameId);
        } 
        // Caso 3: Clicou em qualquer outro lugar do card (Apenas descrição)
        else {
            populateGameModal(gameInfo);
            
            // Oculta o formulário de pagamento para exibir apenas detalhes
            checkoutForm.style.display = 'none';
            gameDetailModal.classList.remove('checkout-mode');
            gameDetailModal.classList.add('active');
        }
    });
});

// Fechar Modal de detalhes
closeDetailBtn.addEventListener('click', () => {
    gameDetailModal.classList.remove('active', 'checkout-mode');
});

// --- SISTEMA DO CARRINHO ---

function addToCart(gameId) {
    const game = gamesData[gameId];
    if (!game) return;

    // Impede duplicados no carrinho
    if (cart.some(item => item.id === gameId)) {
        alert(`${game.title} já está no seu carrinho!`);
        return;
    }

    cart.push({ id: gameId, title: game.title, img: game.img });
    updateCartUI();
    alert(`${game.title} foi adicionado ao carrinho.`);
}

function removeFromCart(gameId) {
    cart = cart.filter(item => item.id !== gameId);
    updateCartUI();
    renderCartItems();
}

// Tratamento preventivo caso os elementos do contador de carrinho não existam em todas as páginas
function updateCartUI() {
    if (cartCount) cartCount.innerText = cart.length;
    if (cartTotalItems) cartTotalItems.innerText = cart.length;
}

function renderCartItems() {
    if (!cartItemsList) return;
    cartItemsList.innerHTML = '';
    
    if (cart.length === 0) {
        cartItemsList.innerHTML = '<p class="empty-cart-text">Seu carrinho está vazio.</p>';
        return;
    }

    cart.forEach(item => {
        const itemRow = document.createElement('div');
        itemRow.className = 'cart-item-row';
        itemRow.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-thumb" style="background-image: url('${item.img}')"></div>
                <span>${item.title}</span>
            </div>
            <button class="btn-remove-item" onclick="removeFromCart('${item.id}')" title="Remover">
                <i class="fa-solid fa-trash"></i>
            </button>
        `;
        cartItemsList.appendChild(itemRow);
    });
}

// Abrir e Fechar Modal do Carrinho Superior
if (openCartBtn) {
    openCartBtn.addEventListener('click', () => {
        renderCartItems();
        if (cartModal) cartModal.classList.add('active');
    });
}

if (closeCartModalBtn) {
    closeCartModalBtn.addEventListener('click', () => {
        if (cartModal) cartModal.classList.remove('active');
    });
}

// Ação de Checkout do Carrinho Completo
if (btnCheckoutCart) {
    btnCheckoutCart.addEventListener('click', () => {
        if (cart.length === 0) {
            alert("Adicione pelo menos um jogo para prosseguir!");
            return;
        }
        if (cartModal) cartModal.classList.remove('active');
        
        // Passa um objeto genérico baseado no primeiro item do carrinho
        const checkoutInfo = {
            title: "Finalizar Pedido do Carrinho",
            synopsis: `Você está adquirindo ${cart.length} jogo(s) selecionado(s).`,
            img: cart[0].img
        };
        
        populateGameModal(checkoutInfo, true);
        
        checkoutForm.style.display = 'block';
        gameDetailModal.classList.add('active', 'checkout-mode');
    });
}

// --- REGRAS DO FORMULÁRIO DE ENVIO ---
if (checkoutForm) {
    checkoutForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Validação dependendo do método selecionado
        if (currentPaymentMethod === 'card') {
            const name = document.getElementById('checkoutName').value.trim();
            const cardNum = document.getElementById('checkoutCard').value.trim();
            const expiry = document.getElementById('checkoutExpiry').value.trim();
            const cvv = document.getElementById('checkoutCvv').value.trim();

            if (!name || !cardNum || !expiry || !cvv) {
                alert('Preencha todos os dados do cartão para concluir a compra.');
                return;
            }

            alert("Compra realizada com sucesso! Seus jogos digitais foram enviados para o e-mail cadastrado.");
            gameDetailModal.classList.remove('active', 'checkout-mode');
            cart = [];
            updateCartUI();
            this.reset();
        } else if (currentPaymentMethod === 'pix') {
            // Exibe instruções PIX; não marca como concluída automaticamente
            const pixText = document.getElementById('pixValue').innerText;
            alert('Use o código PIX exibido para realizar o pagamento:\n' + pixText);
        }
    });
}

paymentOptions.forEach(button => {
    button.addEventListener('click', () => {
        paymentOptions.forEach(opt => opt.classList.remove('active'));
        button.classList.add('active');
        const method = button.dataset.method;
        currentPaymentMethod = method;
        if (method === 'pix') {
            paymentDescription.innerText = 'Pagamento via PIX: escaneie ou copie o código abaixo.';
            if (cardFields) cardFields.style.display = 'none';
            if (pixCode) pixCode.style.display = 'block';
        } else {
            paymentDescription.innerText = 'Pagamento com cartão: preencha os dados abaixo e conclua.';
            if (cardFields) cardFields.style.display = 'block';
            if (pixCode) pixCode.style.display = 'none';
        }
    });
});

if (copyPixBtn) {
    copyPixBtn.addEventListener('click', () => {
        const pixText = document.getElementById('pixValue').innerText;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(pixText).then(() => {
                alert('Código PIX copiado para a área de transferência.');
            }).catch(() => {
                alert('Não foi possível copiar. Selecione e copie manualmente.');
            });
        } else {
            alert('Navegador não suporta cópia automática. Selecione e copie manualmente.');
        }
    });
}

// --- MODAL DE LOGIN GENÉRICO E MENU MOBILE ---
if (openLoginBtn) openLoginBtn.addEventListener('click', () => loginModal && loginModal.classList.add('active'));
if (closeLoginBtn) closeLoginBtn.addEventListener('click', () => loginModal && loginModal.classList.remove('active'));

const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert("Login efetuado com sucesso!");
        if (loginModal) loginModal.classList.remove('active');
    });
}

if (mobileMenu) {
    mobileMenu.addEventListener('click', () => {
        if (menuNav) menuNav.classList.toggle('active');
    });
}

// Fechar modais ao clicar na área escura (overlay)
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active', 'checkout-mode');
    }
});